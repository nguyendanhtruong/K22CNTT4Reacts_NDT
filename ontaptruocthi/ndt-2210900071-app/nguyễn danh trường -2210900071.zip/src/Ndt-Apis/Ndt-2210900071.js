import axios from 'axios'
export default axios.create({
    baseURL:"https://6693aa8fc6be000fa07cd844.mockapi.io/ndtApi/2210900071/"
})